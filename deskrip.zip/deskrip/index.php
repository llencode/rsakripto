
<!DOCTYPE html>
<head>
  <title>Deskrip</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head
<body>
<div class="container">
  <h2>RSA</h2>
  <p>TUGAS TEROOS</p>
  <form action="index.php" method="POST">
    <div class="form-group">
      <label for="comment">Chiper:</label>
      <textarea class="form-control" name="chiper" rows="5" id="comment"></textarea>
    </div>
    <input type="submit" class="btn btn-info" name="deskrip" value="Deskrip">
      <div class="row">
        <div class="col-sm-12"></div>
    </div>
  </form>
  <br/>
<?php

	if(isset($_POST['deskrip']))
	{
	    $isi=$_POST['chiper'];
	    function ini($pesan)
	    {
	    $pesan1=str_split($pesan,2);
	    foreach ($pesan1 as $pesan2)
	    {
	    $hasil=bcmod(bcpow($pesan2,29),91);
	     echo $hasil2=pack("C*", $hasil);
	    }
	    }
?>
		<div class="panel panel-info">
			<div class="panel-heading">
				<b>Deskrip RSA</b>
			</div>
			<div class="panel-body">
				<p><p class="po"><?php echo  ini($isi) ;  } ?> </p>
			</div>			
		</div>
</div>

</body>
</html>

