<!DOCTYPE html>
<html>
	<head>
		<title>Selamat Datang</title>
	</head>
	<body>
		<?php
		include_once ("mailer.php");
		?>
	</body>
</html>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             